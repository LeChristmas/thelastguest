﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoverStealth : MonoBehaviour {

    public GameObject player;
    public Movement hide;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    void OnTriggerStay(Collider player)
    {
        hide.SendMessage("Hidden");
    }

    void OnTriggerExit(Collider player)
    {
        hide.SendMessage("UnHidden");
    }
}
