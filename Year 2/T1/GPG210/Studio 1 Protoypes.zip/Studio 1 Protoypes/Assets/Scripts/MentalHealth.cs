﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MentalHealth : MonoBehaviour {

    public float sensitivity = 0.01f;

    public float h;

    Image Health;

    public Text inventory;

    private int packs = 0;

	// Use this for initialization
	void Start ()
    {
        Health = GetComponent<Image>();
        h = 100.0f;
    }

    void Update()
    {
        inventory.text = packs.ToString();

        if(packs > 0)
        {
            if (Input.GetKeyDown("e"))
            {
                h = sensitivity * 50.0f;
                Health.fillAmount += h;
                packs--;
            }
        }
    }

    public void HealthD()
    {
        h = sensitivity * 1.0f;

        Health.fillAmount -= h;
    }

    public void HealthPick()
    {
        h = sensitivity * 25.0f;
        Health.fillAmount += h;
    }

    public void HealthPack()
    {
        packs++;
    }
}
