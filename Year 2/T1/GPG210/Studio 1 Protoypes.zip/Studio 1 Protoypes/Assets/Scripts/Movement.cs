﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {

    public string ws;
    public string ad;
    public string crouch;

    public Transform cam;

    private float speed;
    private float crouchspeed;

    public float speedH = 2.0f;
    public float speedV = 2.0f;

    private float yaw = 0.0f;
    private float pitch = 0.0f;
    private float pitchY;

    public float minimumY = -60.0f;
    public float maximumY = 60.0f;


    private Quaternion camangle;

    private bool crouched;
    private bool hiding;

    public int enemies;
    public GameObject[] enemy;

    private AIone aione;

    private bool paused = false;

    public float s = 0.1f;
    public float cs = 0.05f;

    // Use this for initialization
    void Start ()
    {
        camangle = cam.rotation;
        crouched = false;
        hiding = false;

        speed = s;
        crouchspeed = cs;

        for(int i = 0; i < enemies; i++)
        {
            aione = enemy[i].gameObject.GetComponent<AIone>();
            
        }
    }
	
    public void Hidden()
    {
        hiding = true;
    }

    public void UnHidden()
    {
        hiding = false;
    }

	// Update is called once per frame
	void Update ()
    {

        // other keys on the keyboard
        if (Input.GetKeyDown(crouch))
        {
            cam.Translate(0.0f, -0.5f, 0.0f);
            crouched = true;
        }
        else if (Input.GetKeyUp(crouch))
        {
            cam.Translate(0.0f, 0.5f, 0.0f);
            crouched = false;
        }


        // movement and mouse controls
        float moveHorizontal = Input.GetAxis(ws);
        float moveVertical = Input.GetAxis(ad);

        if (paused == false)
        {
            yaw += speedH * Input.GetAxis("Mouse X");
            pitch -= speedV * Input.GetAxis("Mouse Y");
            pitchY = Mathf.Clamp(pitch, minimumY, maximumY);
        }

        transform.eulerAngles = new Vector3(0.0f, yaw, 0.0f);
        cam.eulerAngles = new Vector3(pitchY, yaw, 0.0f);

        if (!crouched)
        {
            transform.Translate(moveHorizontal * speed, 0.0f, moveVertical * speed);
            aione.UnHidden();
        }
        else if(crouched)
        {

            transform.Translate(moveHorizontal * crouchspeed, 0.0f, moveVertical * crouchspeed);
            hide.SendMessage("UnHidden");
        }
        else if (crouched && hiding)
        {
            transform.Translate(moveHorizontal * crouchspeed, 0.0f, moveVertical * crouchspeed);
            hide.SendMessage("Hidden");
        }
    }

    public void UnPaused()
    {
        paused = false;
        Debug.Log("not paused");

        speed = s;
        crouchspeed = cs;
    }

    public void Paused()
    {
        paused = true;
        Debug.Log("paused");

        speed = 0.0f;
        crouchspeed = 0.0f;
    }
}