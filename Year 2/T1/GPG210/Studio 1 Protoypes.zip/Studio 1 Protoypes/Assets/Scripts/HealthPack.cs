﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthPack : MonoBehaviour {

    public MentalHealth heal;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void Grab()
    {
        heal.SendMessage("HealthPack");
        Destroy(gameObject);
        Debug.Log("pickedup");
    }
}
